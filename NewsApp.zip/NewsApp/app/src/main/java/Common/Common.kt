package Common

object Common {
    val BASE_URL= "https://newsapi.org/"
    val API_KEY = "03c2dbaebc34416781c52761bd082477"
}